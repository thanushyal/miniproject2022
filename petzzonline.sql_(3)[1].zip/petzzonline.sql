-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 09, 2023 at 12:32 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `petzzonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE IF NOT EXISTS `accessories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`id`, `name`, `price`, `image`) VALUES
(2, 'Fishtank', 300, 'ft1 (8).jpeg'),
(5, 'Dog belts', 1000, 'pets (2) 1.jpeg'),
(6, 'fish tank big', 500, 'ft1 (1).jpeg'),
(7, 'aquariam stones', 200, 'ft1 (9).jpeg'),
(8, 'white Aquariam stones', 250, 'ft1 (5).jpeg'),
(9, 'fish tank medium', 300, 'ft1 (4).jpeg'),
(10, 'dog foods', 200, 'pets.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `create_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminname`, `email`, `password`, `create_datetime`) VALUES
(1, 'sree', 'sree@gmail.com', '202cb962ac59075b964b07152d234b70', '2022-12-05 09:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `birds`
--

CREATE TABLE IF NOT EXISTS `birds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(4) NOT NULL,
  `image` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `birds`
--

INSERT INTO `birds` (`id`, `name`, `price`, `image`) VALUES
(1, 'cocktail', 4000, 'cocktail5 (2).jpg'),
(2, 'cocktail', 3000, '2.jpg'),
(3, 'lovebirds', 1000, 'bird2.jpg'),
(4, 'Budgie', 5000, 'bird3.jpg'),
(5, 'Green parrot', 2000, '7.jpg'),
(6, 'Green parrot', 2000, '7.jpg'),
(7, 'Budgie', 5000, 'bird3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dogs`
--

CREATE TABLE IF NOT EXISTS `dogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(4) NOT NULL,
  `image` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `dogs`
--

INSERT INTO `dogs` (`id`, `name`, `price`, `image`) VALUES
(5, 'crossbreed', 10000, 'joy.jpeg'),
(6, 'Doberman', 5000, 'doberman3.jpg'),
(8, 'labrador', 20000, 'lab.jpeg'),
(11, 'labrador', 7000, 'labrador.jpg'),
(12, 'German', 15000, 'labrador.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fish`
--

CREATE TABLE IF NOT EXISTS `fish` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `fish`
--

INSERT INTO `fish` (`id`, `name`, `price`, `image`) VALUES
(1, 'velitail betta fish', 80, 'unnamed3 (2).jpg'),
(2, 'fantail goldfish', 20, 'unnamed3 (4).jpg'),
(3, 'fantail goldfish', 20, 'unnamed3 (3).jpg'),
(4, 'common gold fish', 100, 'unnamed3 (1).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` tinyint(4) NOT NULL,
  `image` varchar(4000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(0, 'rice', 127, 'Screenshot (8).png'),
(0, 'fish', 30, 'Screenshot (3).png'),
(0, 'labrador', 127, 'lab.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `produ_order`
--

CREATE TABLE IF NOT EXISTS `produ_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phno` bigint(10) NOT NULL,
  `product` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_ordered` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `produ_order`
--

INSERT INTO `produ_order` (`id`, `username`, `email`, `phno`, `product`, `color`, `price`, `address`, `date_ordered`) VALUES
(1, 'ammu', 'ammu@gmail.com', 2147483647, 'Doberman', 'white', 520, '908/13,kunnathur.', '2022-12-17'),
(2, 'ammu', 'ammu@gmail.com', 2147483647, 'Labrador', 'Black', 234, '908/13,kunnathur.', '2022-12-17'),
(3, 'ssss', 'sss@gmail.com', 2147483647, 'cocktail', 'Brown', 520, '908/34,kunndram', '2022-12-17'),
(4, 'nitheesh', 'nitheesh@gmail.com', 9876543210, 'Labrador', 'Black', 544, '546/65 anna nagar', '2022-12-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `create_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `create_datetime`) VALUES
(1, 'Jayasree', 'jayasreeramakrishnan18@gmail.com', '202cb962ac59075b964b07152d234b70', '2022-11-24 09:38:42'),
(2, 'Thanu', 'thanushya@gmail.com', 'a63cae038d7660bec434567c7ccc7504', '2022-11-24 09:39:56'),
(3, 'sree', 'jayasreeramakrishnan18@gmail.com', '202cb962ac59075b964b07152d234b70', '2022-11-30 07:32:49'),
(4, 'thanu', 'thanushya@gmail.com', '202cb962ac59075b964b07152d234b70', '2022-11-30 15:36:16'),
(5, 'renuka', 'renuka@k', 'ef88f3f374aa10d1493757bb6a4046a6', '2022-12-02 04:36:47'),
(6, 'vijitha', 'viji@gmail.com', 'b706835de79a2b4e80506f582af3676a', '2022-12-17 05:27:36'),
(7, 'sree', 'sree@gmail.com', '202cb962ac59075b964b07152d234b70', '2022-12-17 05:28:20');
