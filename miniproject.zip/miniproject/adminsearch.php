<html>
<?php
    include('headeradmin.php');
    ?>
    <head>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text],[type=email],[type=tel],[type=number],select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>

<h3>Get your Report as you want</h3>

<div>
  <form action="adminview.php" method="post">
    <label for="Product">PRODUCT</label>
    <select id="product" name="product">
      <option value="Labrador">Labrador</option>
      <option value="shihtzu">shih tzu </option>
      <option value="Golden Retriever">Golden Retriever</option>
      <option value="crossbreed">crossbreed</option>
      <option value="Doberman">Doberman</option>
      <option value="Golden Retriever">Golden Retriever</option>
      <option value="cocktail">cocktail</option>
      <option value="Green parrot">shih tzu </option>
      <option value="Love birds">Golden Retriever</option>
      <option value="budgies">budgies</option>
      <option value="Doberman">Doberman</option>
      <option value="Golden Retriever">Golden Retriever</option>
    </select>


    <label for="Pet">PETS</label>
    <select id="pets" name="pets">
      <option value="birds">birds</option>
      <option value="dogs">dogs </option>
      <option value="fish">fish</option>
      <option value="accessories">accessories</option>
    </select>

  
    <input type="submit" name="submit">
  </form>
</div>
</body>
</html>


