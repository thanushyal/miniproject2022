<?php
include('db.php');

$select = mysqli_query($con, "SELECT * FROM dogs");
include('homesheader.php');
?>

<div class="product-display">
   <table class="product-display-table" id="products">
      <thead>
      <tr>
         <th>IMAGE</th>
         <th>DOG NAME</th>
         <th>PRICE</th>
      </tr>
      </thead>
      <?php while($row = mysqli_fetch_assoc($select)){ ?>
      <tr>
         <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="100" alt="" width="100"></td>
         <td><?php echo $row['name']; ?></td>
         <td>Rs<?php echo $row['price']; ?>/-</td>
      </tr>
   <?php } 
   ?>
   </table>
</div>