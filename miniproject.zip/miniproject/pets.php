<html>
    <head>
        <title>
            pets
        </title>
    </head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

body {
  background-color: #151719;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.waviy {
  position: relative;
  -webkit-box-reflect: below -20px linear-gradient(transparent, rgba(0,0,0,.2));
  font-size: 60px;
}
.waviy span {
  font-family: 'Alfa Slab One', cursive;
  position: relative;
  display: inline-block;
  color: #fff;
  text-transform: uppercase;
  animation: waviy 1s infinite;
  animation-delay: calc(.1s * var(--i));
  
}
@keyframes waviy {
  0%,40%,100% {
    transform: translateY(0)
  }
  20% {
    transform: translateY(-20px)
  }
}
.button {
  border-radius: 4px;
  background-color: #151719;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}

    </style>
    <body>
            <div class="waviy">
              <span style="--i:1">C</span>
              <span style="--i:2">H</span>
              <span style="--i:3">O</span>
              <span style="--i:4">O</span>
              <span style="--i:5">S</span>
              <span style="--i:6">E</span>
              <span style="--i:7"> </span>
              <span style="--i:8">Y</span>
              <span style="--i:9">O</span>
              <span style="--i:10">U</span>
              <span style="--i:11">R</span>
              <span style="--i:12">S</span>
              <span style="--i:13"> </span>
              <span style="--i:14"> </span>
              <span style="--i:15"> </span>
              <span style="--i:16"> </span>
              <span style="--i:17"> </span>
              <span style="--i:18"> </span>
              <span style="--i:19"> </span>
              <span style="--i:20"> </span>
              <span style="--i:21"> </span>
              <span style="--i:22"> </span>
              <span style="--i:23"> </span>
              <span style="--i:24"> </span>
              <span style="--i:25"> </span>
             </div>
    <div>
        <form action="dogs.php" method="GET">
        <button class="button"><span>Dogs</span></button></form>
        <form action="birds.php" method="GET">
        <button class="button"><span>Birds</span></button></form>
        <form action="fishes.php" method="GET">
        <button class="button"><span>Fish</span></button></form>   
        <form action="accessory.php" method="GET">
        <button class="button"><span>Things</span></button></form>     
    </div>
    
    
    </body>
    
</html>