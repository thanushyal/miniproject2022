<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text],[type=email],[type=tel],[type=number],select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<?php
include('header.php');?>
<body>

<h3><center>Contact Form<center></h3>

<div class="container">
  <form action="myorder.php" method="POST">
    <label for="fname">User Name</label>
    <input type="text" name="username" placeholder="Your name.." required><br><br>

    <label for="Email">Email</label>
    <input type="email"  name="email" placeholder="Your email.." required><br><br>

    <label for="phno">Phone Number</label>
    <input type="number" name="phno" placeholder="Your phno.."  required><br><br>

    <label for="pets">Pets/Product</label>
    <select id="pets" name="product">
      <option value="Labrador">Labrador</option>
      <option value="shihtzu">shih tzu </option>
      <option value="Golden Retriever">Golden Retriever</option>
      <option value="crossbreed">crossbreed</option>
      <option value="Doberman">Doberman</option>
      <option value="Golden Retriever">Golden Retriever</option>
      <option value="cocktail">cocktail</option>
      <option value="Green parrot">shih tzu </option>
      <option value="Love birds">Golden Retriever</option>
      <option value="budgies">budgies</option>
      <option value="Doberman">Doberman</option>
      <option value="Golden Retriever">Golden Retriever</option>
    </select>

    <label for="color">Color</label>
    <select id="pets" name="color">
      <option value="Black">Black</option>
      <option value="white">white </option>
      <option value="Brown">brown</option>
      <option value="Golden">Golden</option>
      <option value="Green">Green </option>
      <option value="Yellow">Yellow</option>
</select>

    <label for="price">Price</label>
    <input type="number" name="price" placeholder="price.." required><br><br>

    <label for="Address">Address</label>
    <textarea  name="address" placeholder="Write something.." style="height:200px" required></textarea>

    <label for="Date">Today's Date</label>
    <input type="date" name="date" placeholder="Date" required><br><br>


    <input type="submit" name="submit" value="Submit" >
  </form>
</div>

</body>
</html>
