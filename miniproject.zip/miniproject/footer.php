<br><hr><br id="aboutus">
<div class="aboutus">
<div class="container">
<h1 id="aboutus">ABOUT US</h1>
<p>Welcome to PETZZ ONLINE, your number one source for all variety of pets.<br> We're dedicated to providing you the very best of our services, with an emphasison providing you the pets.<br>
Founded in 2022 by Manoj,PETZ ONLINE has come a long way from its beginnings in Tamil Nadu.When Manoj first started out, his passion for to get all variety of PETS drove 
them to start their own business.
<br> We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.</p>
<br><hr id="contact"><br>
<h1 id="contact">Contact Us</h1>
<p >Get in Touch with Us.<br>
<i class="glyphicon glyphicon-phone-alt"></i> Phone number:<a href="9994538282">9994538282</a><br><i class="glyphicon glyphicon-envelope" ></i>Email:<a style="color:#38a2f7;text-decoration: underline;" href="mailto:petzzonline@gmail.com">petzzonline@gmail.com</a><br><i class="glyphicon glyphicon-earphone"></i> Whatsapp:<a href="https://wa.me/+919994538282">+919994538282</a><br></p>
<br><hr><br>
<h1 style="font-size: 30px;">Follow Us</h1>
<div class="row">
<div class="col-xs-4">
<a href="https://www.facebook.com/profile.php?id=100087311025344">Facebook</a><br></div>
<div class="col-xs-4">
<a href="https://instagram.com/petzzonline?igshid=YmMyMTA2M2Y=">Instagram</a><br></div>
<div class="col-xs-4">
<a href="https://twitter.com/PETZZ_ONLINE?t=J_ABaL3s4DARd0GxpPgA0Q&s=09">Twitter</a></div>
</div>
<br><hr>
</div>
</div>

