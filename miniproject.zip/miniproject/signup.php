<!DOCTYPE html>
<html>
    <head>
        <title>Signup</title>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    </head>
    <body >
<section class="text-center text-lg-start">
    <style>
      .cascading-right {
        margin-right: -50px;
      }
  
      @media (max-width: 991.98px) {
        .cascading-right {
          margin-right: 0;
        }
      }
    </style>
  <div class="container">
    <div style="font-size: 35px; font-weight: 600;font-family: Arial, Helvetica, sans-serif;padding: 20px;">
      <span style='color:#FF0000;'>PETZZ</span> <span style='color:#8D0071;'>ONLINE</span>
  </div>
    <div class="container py-10">
      <div class="row g-0 align-items-center">
        <div class="col-lg-6 mb-5 mb-lg-0">
          <div class="card cascading-right" style="
              background: hsla(180, 8%, 97%, 0.958);
              backdrop-filter: blur(30px);
              ">
            <div class="card-body p-5 shadow-5 text-center">
              <h2 class="fw-bold mb-5">REgister..!</h2>
              <form action="login.html" method="get">
                <div class="form-outline mb-4">
                    <input type="text" id="form3Example3" placeholder="Enter username" name="username" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                  <input type="password" id="form3Example4" placeholder="Enter Password" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                    <input type="email" id="form3Example3" placeholder="Enter Email" name="email" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                  <input type="address" id="form3Example3" placeholder="Enter Address" name="username" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                  <input type="number" id="form3Example3" placeholder="Enter your phnumber 0123456789" name="phnum" class="form-control" />
                </div>
                <button type="submit" name="Register" class="btn btn-primary btn-block mb-4">
                  Register
                </button>    
              </form>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </section>
    </body>
</html>