<!DOCTYPE html>
<html>
  
<head>
    <meta charset="utf-8">
    <title>Customize the scroll-bar</title>
  
    <?php include('homesheader.php');
    ?>
</head>
</head>
<body>
    <center>
        
        <h1 style="color:black;">
            Location to reach us..!
        </h1>
          
        <div>
            <!-- Google Map Copied Code -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3912.718002245125!2d77.58282831475357!3d11.282127791979587!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba96d6a873444cb%3A0xd34ba64d084f70b!2sSri%20Lakshmi%20Pet%20Shop!5e0!3m2!1sen!2sin!4v1669943143404!5m2!1sen!2sin" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
         </div>
    </center>
   
    <h3>No 136/1, Kanjikovil Road, Perundurai West, Perundurai - 638052, Near Nayara Petrol Bunk (Map)</h3>
    <h3>Opens at 10am and closes at 8pm</h3>
    <h3><b>Pets are our Passion<br><br>
    One stop for all pet care needs<br><br>
    Retailer of all pet food and products<b></h3><br>
    <center>
    <h4><u><b><span style="color:blue;font-weight:bold">We also provide you with the functionality to sell your pets too..</span></b></u></h4><br>
    <h4><u><b><span style="color:blue;font-weight:bold">For selling your prefered pets contact us:9994538282</span></b></u></h4> 
    </center>
    <?php
include('footer.php');
?>
</body>
  
</html>