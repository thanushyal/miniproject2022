<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>Get your favourite fish!</h1>
   <p>Choose your favourite fish in a affordable price</p> 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>NAME</h3>
      <p><b>Velitail Betta Fish</b></p>
      <p>Veiltail bettas are a beloved choice of bettas for their attractive fin display.</p><br><br>
      <p><b>Veiltai</b></p>
      <p>The veiltail is a type of goldfish known for its extra-long, flowing double tail and high sail-like dorsal fin.</p>
      <br><br>
      <p><b>Fantail Goldfish</b></p>
      <p>The Fantail is a goldfish that possesses an egg-shaped body, a high dorsal fin, a long quadruple caudal fin, and no shoulder hump.It is similar to the Ryukin, and is relatively common in western countries.</p><br><br>
      <p><b></b></p>
      <p><b>Common Goldfish</b></p>
      <p>The common goldfish is a breed of goldfish with no other differences from its living ancestor, the Prussian carp, other than its color and shape.</p>
    </div>
    <div class="col-sm-4">
      <h3>IMAGE</h3>
      <img src="unnamed3 (1).jpg" class="rounded-circle" width="200" height="180"><br>
      <img src="unnamed3 (2).jpg" class="rounded-circle" width="200" height="180"><br><br>
      <img src="unnamed3 (3).jpg"   class="rounded-circle" width="200" height="180"><br><br>
      <img src="unnamed3 (4).jpg" class="rounded-circle" width="200" height="180"><br><br>
      
    </div>
    <div class="col-sm-4">
      <h3>PRICE</h3>
      <p>rs 80</p><br><br><br><br><br><br><br><br>
      <p>rs 80</p><br><br><br><br><br><br><br>
      <p>rs 20(1piece)</p><br><br><br><br><br><br><br><br>
      <p>rs 100</p><br><br><br><br><br><br><br>
    </div>
  </div>
</div>

</body>
</html>