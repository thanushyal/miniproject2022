<html>
    <head>
        <title>
            Text effects
        </title>
    </head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

body {
  background-color:  #151719;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.waviy {
  position: relative;
  -webkit-box-reflect: below -20px linear-gradient(transparent, rgba(0,0,0,.2));
  font-size: 60px;
}
.waviy span {
  font-family: 'Alfa Slab One', cursive;
  position: relative;
  display: inline-block;
  color: #fff;
  text-transform: uppercase;
  animation: waviy 1s infinite;
  animation-delay: calc(.1s * var(--i));
  
}
@keyframes waviy {
  0%,40%,100% {
    transform: translateY(0)
  }
  20% {
    transform: translateY(-20px)
  }
}
    </style>
    <body>
            <div class="waviy">
              <span style="--i:1">P</span>
              <span style="--i:2">E</span>
              <span style="--i:3">T</span>
              <span style="--i:4">Z</span>
              <span style="--i:5">Z</span>
              <span style="--i:6">O</span>
              <span style="--i:7">N</span>
              <span style="--i:8">L</span>
              <span style="--i:9">I</span>
              <span style="--i:10">N</span>
              <span style="--i:11">E</span>
             </div>
             
    </body>
</html>