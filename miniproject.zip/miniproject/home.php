<html>
<?php
include('header.php');
?>
<body >
<div >
<div class="container">


</div>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    * {box-sizing: border-box}
    body {font-family: Verdana, sans-serif; margin:0}
    .mySlides {display: none}
    img {vertical-align: middle;}
    
    
    /* Next & previous buttons */
    .prev, .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
    }
    .next {
      right: 0;
      border-radius: 3px 0 0 3px;
    }
    .prev:hover, .next:hover {
      background-color: rgba(0,0,0,0.8);
    }
    .dot {
      cursor: pointer;
      height: 10px;
      width: 10px;
      margin: 0 2px;
      background-color: #bbb;
      border-radius: 50%;
      display: inline-block;
      transition: background-color 0.6s ease;
    }
    
    .active, .dot:hover {
      background-color: #717171;
    }
    
    /* Fading animation */
    .fade {
      animation-name: fade;
      animation-duration: 1.5s;
    }
    
    @keyframes fade {
      from {opacity: .4} 
      to {opacity: 1}
    }
    
    /* On smaller screens, decrease text size */
    @media only screen and (max-width: 100px) {
      .prev, .next,.text {font-size: 11px}
    }
    div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

    </style>
    </head>
    <body>
    <br>
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="thumbnail">
            
              <img src="1.jpg" alt="Lights" style="width:100%,height=50;">
              <div class="caption">
              <a href="">cocktail</a>
              <p>From Rs.2000</p>
              <p>A cockatiel is a popular choice for a pet bird. It is a small parrot with a variety of color patterns and a head crest.</p>
              </div>
            
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
              <img src="GloFish.jpg" alt="Nature" style="width:100%,height=50;">
              <div class="caption">
              <a href="">GloFish</a>
              <p>From Rs.200</p>
              <p>Glofish can make fantastic pets for adults and kids alike. </p>
              </div>
           
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
      
              <img src="border1.jpg" alt="Fjords" style="width:100%">
              <div class="caption">
              <a href="" >Border dog</a>
              <p>From Rs.2000</p>
              <p>The Border Collie is a Scottish breed of herding dog of medium size.</p>
              </div>
          
          </div>
        </div>
      </div>
    </div> 
<div style="background-color: rgb(242, 240, 240)">
<br><br>
<div class="container" width="60%" height="60%">
<div class="row" style="padding: 0px 25px;">
<div class="col-sm-5">
<img src="pets (7) 1.jpeg" height="500" width="500"/>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-5">
  <div class="container" width="60%">
<div class="the">
<br>
<p>Looking for birds...?</p>
<p>pick the new variety of bird as your beloved one!!! </p>
<a href="bird.php" id="job">Get your favourite Bird</a>
</div>
<div class="the">
  <br>
  <p>Looking for dogs...?</p>
  <p>pick the new variety of dogs as your beloved one!!! </p>
  <a href="dog.php" id="job">Get your favourite Dog</a>
  </div>
  <div class="the">
    <br>
    <p>Looking for fish...?</p>
    <p>pick the new variety of dogs as your beloved one!!! </p>
    <a href="fish.php" id="job">Get your favourite fish</a>
    </div>
</div>
<div class="the">
<p id="join"></p></div>
</div>
</div>
</div>
<br></div>
<?php
include('footer.php');
?>
</body>
</html>
