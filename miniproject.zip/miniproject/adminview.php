<html>
<style>
caption {
    font-size: 1.8rem;
}
table {
    width: 60%;
    font-size: 1.2rem;
    margin: 20px auto;
}
 
tbody tr:nth-child(odd) {
    background: #202932;
}
 
tbody tr:nth-child(even) {
    background: #2c3844;
}
 
tbody {
    color: white;
}
 
table, td, th {
    border-collapse: collapse;
}
 
th, td {
    padding: 10px;
    border: 1px solid #777;
    text-align: center;
}
 
.firstRowFirstColumn {
    width: 400px;}
</style>
    <body>
<?php
include('headeradmin.php');
include('db.php');
if(isset($_POST['submit']))
{
    
    $product=$_REQUEST['product'];
    $sql="SELECT * FROM produ_order WHERE product='$product'";
    $sql=mysqli_query($con,$sql);
}
?>
<table id="customer" border="1">
<tr>
<th>ID</th>
<th>USERNAME</th>
<th>EMAIL</th>
<th>PHONE NUMBER</th>
<th>PRODUCT</th>
<th>COLOR</th>
<th>PRICE</th>
<th>ADDRESS</th>
<th>DATE ORDERED</th>

</tr>
<?php
include('db.php');
$sql="SELECT * FROM produ_order WHERE product='$product'";
$sql=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($sql))
{
?>
<tr>
<td><?php echo $row['id'];?></td>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['phno'];?></td>
<td><?php echo $row['product'];?></td>
<td><?php echo $row['color'];?></td>
<td><?php echo $row['price'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['date_ordered'];?></td>
</tr>
<?php
}
?>
</table>
</body>
</html>
