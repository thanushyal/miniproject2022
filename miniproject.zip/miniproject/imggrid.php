<!DOCTYPE html>
<html lang="en">
<head>
  <title>Gallery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

</style>
<body>

<div class="container">
  <h2>Image Gallery</h2>
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (7) 1.jpeg" target="_blank">
          <img src="pets (7) 1.jpeg" alt="Lights" style="width:100,height=50;">
          <div class="caption">
            <p>About us</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (6) 1.jpeg" target="_blank">
          <img src="pets (6) 1.jpeg" alt="Nature" style="width:100,height=50;">
          <div class="caption">
            <p>Cross Breed</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (5) 1.jpeg" target="_blank">
          <img src="pets (5) 1.jpeg" alt="Fjords" style="width:100,height=50;">
          <div class="caption">
            <p>Begale male</p>
          </div>
        </a>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (1) 1.mp4" target="_blank">
          <img src="pets (1) 1.mp4" alt="Lights" style="width:100,height=50;">
          <div class="caption">
            <p>Our care for pets</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (6) 1.jpeg" target="_blank">
          <img src="pets (6) 1.jpeg" alt="Nature" style="width:100,height=50;">
          <div class="caption">
            <p>Cross Breed</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="pets (5) 1.jpeg" target="_blank">
          <img src="pets (5) 1.jpeg" alt="Fjords" style="width:100,height=50;">
          <div class="caption">
            <p>Begale male</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>

</body>
</html>


