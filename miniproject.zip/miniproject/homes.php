<html>
<head>
<script src="index.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<?php
include('homesheader.php');
?>
    <body>
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="thumbnail">
            
              <img src="1.jpg" alt="Lights" style="width:100%,height=50;">
              <div class="caption">
              <a href="">cocktail</a>
              <p>From Rs.2000</p>
              <p>A cockatiel is a popular choice for a pet bird. It is a small parrot with a variety of color patterns and a head crest.</p>
              </div>
            
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
              <img src="GloFish.jpg" alt="Nature" style="width:100%,height=50;">
              <div class="caption">
              <a href="">GloFish</a>
              <p>From Rs.200</p>
              <p>Glofish can make fantastic pets for adults and kids alike. </p>
              </div>
           
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
      
              <img src="border1.jpg" alt="Fjords" style="width:100%">
              <div class="caption">
              <a href="" >Border dog</a>
              <p>From Rs.2000</p>
              <p>The Border Collie is a Scottish breed of herding dog of medium size.</p>
              </div>
          
          </div>
        </div>
      </div>
    </div> 
<div style="background-color: rgb(242, 240, 240)">
<br><br>
<div class="container" >
<div class="row" style="padding: 0px 25px;">
<div class="col-sm-5">
 
<img src="pets (7) 1.jpeg" height="500" width="500"/>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-5">
<div class="the">
<br>
<p>Looking for birds...?</p>
<p>pick the new variety of bird as your beloved one!!! </p>
<a href="bird.php" id="job">Get your favourite Bird</a>
</div>
<div class="the">
  <br>
  <p>Looking for dogs...?</p>
  <p>pick the new variety of dogs as your beloved one!!! </p>
  <a href="dog.php" id="job">Get your favourite Dog</a>
  </div>
  <div class="the">
    <br>
    <p>Looking for fish...?</p>
    <p>pick the new variety of dogs as your beloved one!!! </p>
    <a href="fish.php" id="job">Get your favourite fish</a>
    </div>
<div class="the">
<p id="join"></p></div>
</div>
</div>
</div>
<br></div>
</div>
<?php
include('footer.php');
?>
</body>
</html>
