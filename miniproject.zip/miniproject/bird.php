<?php
include('db.php');

$select = mysqli_query($con, "SELECT * FROM birds");
include('header.php');
?>
<style>
.firstRowFirstColumn {
    width: 10%;}
</style>
<div class="container">
<div class="product-display">
   <table class="product-display-table" id="products">
      <div class="row">
      <thead>
      <tr>
         <th>IMAGE</th>
         <th>BIRD NAME</th>
         <th>PRICE</th>
      </tr>
      </thead>
      <?php while($row = mysqli_fetch_assoc($select)){ ?>
      <tr>
         <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="100" alt="" width="100"></td>
         <td><?php echo $row['name']; ?></td>
         <td>Rs<?php echo $row['price']; ?>/-</td>
      </tr>
   <?php } 
   ?>
   </div>
   </table>
</div>
</div>