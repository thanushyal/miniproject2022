<head>
<script src="index.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
.aboutus p{
font-size: 22px;
padding: 20px;
font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.aboutus a{
text-align: center;
font-size: 20px;
padding: 20px;
font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.aboutus{
background-color: rgb(10, 11, 11);
color: rgb(251, 251, 251);
}
.aboutus h1{
text-align: center;
text-decoration: underline;
font-size: 45px;
color: rgb(108, 7, 56);
}
.the a{
color: rgb(14, 6, 241);
font-size: 25px;
}
.the p{
font-size: 25px;
font-weight: bolder;
font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
color: rgb(10, 10, 10);
}
body .bbbootstrap {
background-size:100%;
padding: 150px 0 20px 0
}
.bbbootstrap form {
position: relative;
width: 300px;
margin: 22px auto 0
}
span {
margin: 0;
padding: 0;
border: 0;
outline: 0;
font-weight: inherit;
font-style: inherit;
font-size: 100%;
font-family: inherit;
vertical-align: baseline
}
.bbbootstrap form input[type="text"] {
padding: 15px 20px;
padding-right:50px;
border-color: transparent;
border-radius: 8px
}
input.InputBox {
font-family: "lucida grande", "Lucida Sans Unicode", tahoma, sans-serif;
color: #333;
font-size: 15px;
padding: 3px;
margin: 0;
width: 150px;
background: rgb(226, 219, 219);
border: 1px solid #999;
border: 1px solid rgba(0, 0, 0, 0.4)
}
input[type=text] {
box-sizing: border-box
}
.InputBox {
display: block;
width: 100% !important;
padding: 4px 10px;
font-size: 14px;
line-height: 22px;
border-radius: 4px
}
.bbbootstrap form input[type="submit"] {
position: absolute;
top: 5px;
right: 5px;
float: right;
padding: 10px 25px
}
body .Button,
body .button {
background-color: #1268b3;
background-image: none
}
input[type="submit"] {
-webkit-appearance: button;
cursor: pointer
}
.Button,
.Button:hover,
.Button:focus,
.Button:active {
text-shadow: none;
border-color: transparent
}
.Button {
display: inline-block;
padding: 6px 12px;
vertical-align: middle;
font-size: 10px;
font-weight: 700;
line-height: 22px;
text-transform: uppercase;
border: transparent solid 1px;
border-radius: 3px;
-webkit-transition: -webkit-box-shadow 50ms;
transition: -webkit-box-shadow 50ms;
-o-transition: box-shadow 50ms;
transition: box-shadow 50ms;
transition: box-shadow 50ms, -webkit-box-shadow 50ms;
-webkit-font-smoothing: inherit;
color: rgb(247, 244, 244);
background-color: #2e9df7;
background-repeat: repeat-x;
background-color: #38a2f7;
background-image: -webkit-linear-gradient(#38a2f7, #2498f7);
background-image: -webkit-gradient(linear, left top, left bottom, from(#38a2f7), to(#2498f7));
background-image: -o-linear-gradient(#38a2f7, #2498f7);
background-image: linear-gradient(#38a2f7, #2498f7)
}
</style>



<nav class="navbar navbar-inverse navbar-expand-lg text-dark" style="background-color:black;font-size: 20px;">
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<div style="font-size: 35px; font-weight: 600;font-family: Arial, Helvetica, sans-serif;padding: 0 12px 0 12px;">
<i class="material-icons" style="font-size:40px;color:white">pets</i>
    <span style='color:#FF0000;'>PETZZ</span> <span style='color:#8D0071;'>ONLINE</span>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
<li><a href="homeadmin.php">HOME</a></li>
<li><a href="pets2d.php" style="font-size: 20px;">PETS</a></li>
<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         ADD CATEGORY
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="admin_pagedog.php">DOG</a><br>
          <a class="dropdown-item" href="admin_pagebirds.php">BIRD</a><br>
          <a class="dropdown-item" href="admin_pagefish.php">FISH</a><br>
          <a class="dropdown-item" href="admin_pageaccessories.php">ACCESSORIES</a><br>
        </div>
      </li>
<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         VIEW DETAILS
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="adminorder.php">ORDER DETAIL</a><br>
          <a class="dropdown-item" href="adminuser.php">USER DETAILS</a><br>
          <a class="dropdown-item" href="adminsearch.php">SEARCH</a><br>
          
        </div>
      </li>
 
</ul>
<ul class="nav navbar-nav navbar-right">
<li> <a href="googlemap.php"><span class="glyphicon glyphicon-map-marker"></span>LOCATION</a></li>
<li> <a href="admindashboard.php"><span class="glyphicon glyphicon-log-out"></span>LOGOUT</a></li>
 
</ul>
</div>
</div>
</div>
</nav>
</head>