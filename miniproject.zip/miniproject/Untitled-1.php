$to = "$email";
$from = "petzzonline@gmail.com";
$user = "$user";
   

$headers = "From: $from";
$headers = "From: " . $from . "\r\n";
$headers .= "Reply-To: ". $to . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$subject = "You have registered successfully.Do not share your login details..To continue please login!!";

$logo = 'http://iatomtech.com/img/iatom-logo.png';
$link = 'http://iatomtech.com/';

$body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Express Mail</title></head><body>";
$body .= "<table style='width: 100%;'>";
$body .= "<thead style='text-align: center;'><tr><td style='border:none;' colspan='2'>";
$body .= "<a href='{$link}'><img src='{$logo}' style='max-height: 33px;' alt='IAtom Technology'></a><br><br>";
$body .= "</td></tr></thead><tbody><tr>";
$body .= "<td style='border:none;'><strong>Name:</strong> {$user}</td>";
$body .= "<td style='border:none;'><strong>Email:</strong> {$from}</td></tr>";
$body .= "</tr>";
$body .= "</tbody></table>";
$body .= "</body></html>";
$send .= mail($to, $subject, $body, $headers);


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="petzzonline";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if(isset($_REQUEST['login']))
{ 
  $email=$_REQUEST['email'];
  $password=$_REQUEST['password'];
  $sql="SELECT $email from signup where ($email==$email)";
  $sql=mysqli_query($conn,$sql);
  if($sql==$email)
  {
    echo ("alert('you have logged in successfully!!')");
  }
  else
  {
    echo ("alert('Don't have an account ..! Do register..!)");
  }
}
?>

background: #3e4144;

<?php

$search = $_POST['search'];
$servername = "localhost";
$username = "root";
$password = "";
$db = "petzzonline";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select * from students where $search like '%$search%'";

$result = $conn->query($sql);
if ($result->num_rows > 0)
{
while($row = $result->fetch_assoc() ){
	echo $row["name"]."  ".$row["age"]."  ".$row["gender"]."<br>";
}
} else {
	echo "0 records";
}

$conn->close();

?>


<html>
    <head>
        <title>Addcart</title>
    </head>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Quicksand:400,700');
*, ::before, ::after { box-sizing: border-box; }
body{
  font-family:'Quicksand', sans-serif;
  text-align:center;
  line-height:1.5em;
/*   background:#E0E4CC; */
 background: #69d2e7;
background: -moz-linear-gradient(-45deg, #69d2e7 0%, #a7dbd8 25%, #e0e4cc 46%, #e0e4cc 54%, #f38630 75%, #fa6900 100%);
background: -webkit-linear-gradient(-45deg, #69d2e7 0%,#a7dbd8 25%,#e0e4cc 46%,#e0e4cc 54%,#f38630 75%,#fa6900 100%);
background: linear-gradient(135deg, #69d2e7 0%,#a7dbd8 25%,#e0e4cc 46%,#e0e4cc 54%,#f38630 75%,#fa6900 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#69d2e7', endColorstr='#fa6900',GradientType=1 );
}
hr {
  border:none;
  background:#E0E4CC;
  height:1px;
/*   width:60%;
  display:block;
  margin-left:0; */
}
.container {
  margin: 1em auto; 
  background:#FFF; 
  padding:30px;
  width:100%;
  border-radius:5px;
}
.productcont {
  display: flex; 
  width:100%;
}
.product {
  padding:1em; 
  border:1px solid #E0E4CC; 
  margin-right:1em; 
  border-radius:5px;
}
.cart-container {
  border:1px solid #E0E4CC;
  border-radius:5px;
  margin-top:1em;
  padding:1em;
}
button, input[type="submit"] { 
    border:1px solid #FA6900; 
    color:#fff; 
    background: #F38630; 
    padding:0.6em 1em;
    font-size:1em; 
    line-height:1; 
    border-radius: 1.2em;
    transition: color 0.2s ease-in-out, background 0.2s ease-in-out, border-color 0.2s ease-in-out;
}
button:hover, button:focus, button:active, input[type="submit"]:hover, input[type="submit"]:focus, input[type="submit"]:active {
    background: #A7DBD8;
    border-color:#69D2E7;
    color:#000;
    cursor: pointer;
}
table {
  margin-bottom:1em;
  border-collapse:collapse;
}
table td, table th {
  text-align:left;
  padding:0.25em 1em;
  border-bottom:1px solid #E0E4CC;
}
#carttotals {
  margin-right:0;
  margin-left:auto;
}
.cart-buttons {
  width:auto;
  margin-right:0;
  margin-left:auto;
  display:flex;
  justify-content:flex-end;
  padding:1em 0;
}
#emptycart {
  margin-right:1em;
}
table td:nth-last-child(1) {
  text-align:right;
}
.message {
  border-width: 1px 0px;
  border-style:solid;
  border-color:#A7DBD8;
  color:#679996;
  padding:0.5em 0;
  margin:1em 0;
}
#header {
  background-color: #cbc2c2;
  background-image:;
  padding: 50px 10px;
  color: black;
  text-align: center;
  font-size: 20px; 
  font-weight: bold;
  position: fixed;
  top: 0;
  width:100%;
  transition: 0.5s;
}
    </style>
    <body>
        <div class="container"> 
            <div id="header">
            <p>GRAB YOUR FAVOURITE BIRD..</p></div>
            <p>Animals have come to mean so much in our lives. We live in a fragmented and disconnected culture. Politics are ugly, religion is struggling, technology is stressful, and the economy is unfortunate. What’s one thing that we have in our lives that we can depend on? A dog or a cat loving us unconditionally, every day, very faithfully.</p>
         <div class="productcont">
          <form action=" " method="POST">
                 <div class="product" name ="product1">
                     <img src="WhatsApp Image 2022-11-18 at 11.10.26 AM.jpeg" height="400" width="300">
                     <p class="productname">Conure</p>
                     <p class="price">Rs 10000 </p>
                     <button class="addtocart" name="b1">Add To Cart</button>
                 </div>
                 <div class="product" name="product2">
                    <img src="WhatsApp Image 2022-11-18 at 11.10.27 AM.jpeg" height="400" width="300">
                     <p class="productname">Conure</p>
                     <p class="price">Rs 10000</p>
                     <button class="addtocart" name="b2">Add To Cart</button>
                 </div>
                 <div class="product" name="product3">
                    <img src="bird1.jpg" height="400" width="300">
                    <p class="productname">cocktail</p>
                     <p class="price">Rs 2000</p>
                     <button class="addtocart" name="b3">Add To Cart</button>
                 </div>
                 <div class="product" name="product4">
                    <img src="bird2.jpg" height="400" width="300">
                    <p class="productname">Rs 4000</p>
                     <p class="price">Green parot</p>
                     <button class="addtocart" name="b4">Add To Cart</button>
                 </div>
                 </div>
</div>
                 <div class="productcont">
                    <div class="product" name="product5">
                        <img src="bird3.jpg" height="400" width="300">
                        <p class="productname">Love birds</p>
                        <p class="price">Rs 500</p>
                        <button class="addtocart" name="b5">Add To Cart</button>
                    </div>
                    <div class="product" name="product6">
                       <img src="cocktail5 (3).jpg" height="400" width="300">
                        <p class="productname">cocktail</p>
                        <p class="price"></p>
                        <button class="addtocart" name="b6">Add To Cart</button>
                    </div>
                    <div class="product" name="product7">
                      <img src="cocktail5 (1).jpg" height="400" width="300">
                      <p class="productname">cocktail</p>
                      <p class="price">Rs 500</p>
                      <button class="addtocart" name="b7">Add To Cart</button>
                  </div>
                  <div class="product" name="product8">
                     <img src="cocktail5 (2).jpg" height="400" width="300">
                      <p class="productname" name="b8">Cocktail</p>
                      <p class="price"></p>
                      <button class="addtocart">Add To Cart</button>
                  </div>
                 </div>
                 <div class="cart-container">
                   <h2>Cart</h2>
                   <table>
                     <thead>
                       <tr>
                       <th><strong>Product</strong></th>
                       <th><strong>Price</strong></th>
                     </tr>
                     </thead>
                     <tbody id="carttable">
                     </tbody>
                   </table>
                   <hr>
                   <table id="carttotals">
                     <tr>
                       <td><strong>Items</strong></td>
                       <td><strong>Total</strong></td>
                     </tr>
                     <tr>
                       <td>x <span id="itemsquantity">0</span></td>
                      
                       <td>$<span id="total">0</span></td>
                     </tr></table>
         
                     
                   <div class="cart-buttons">  
                     <button id="emptycart">Empty Cart</button>
                     <button id="checkout">Checkout</button>
                   </div>
                 </div>
         </div>
</form>
<script>
updateCartTotal();
document.getElementById("emptycart").addEventListener("click", emptyCart);
var btns = document.getElementsByClassName('addtocart');
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener('click', function() {addToCart(this);});
}

/* ADD TO CART functions */

function addToCart(elem) {
    //init
    var sibs = [];
    var getprice;
    var getproductName;
    var cart = [];
     var stringCart;
    //cycles siblings for product info near the add button
    while(elem = elem.previousSibling) {
        if (elem.nodeType === 3) continue; // text node
        if(elem.className == "price"){
            getprice = elem.innerText;
        }
        if (elem.className == "productname") {
            getproductName = elem.innerText;
        }
        sibs.push(elem);
    }
    //create product object
    var product = {
        productname : getproductName,
        price : getprice
    };
    //convert product data to JSON for storage
    var stringProduct = JSON.stringify(product);
    /*send product data to session storage */
    
    if(!sessionStorage.getItem('cart')){
        //append product JSON object to cart array
        cart.push(stringProduct);
        //cart to JSON
        stringCart = JSON.stringify(cart);
        //create session storage cart item
        sessionStorage.setItem('cart', stringCart);
        addedToCart(getproductName);
        updateCartTotal();
    }
    else {
        //get existing cart data from storage and convert back into array
       cart = JSON.parse(sessionStorage.getItem('cart'));
        //append new product JSON object
        cart.push(stringProduct);
        //cart back to JSON
        stringCart = JSON.stringify(cart);
        //overwrite cart data in sessionstorage 
        sessionStorage.setItem('cart', stringCart);
        addedToCart(getproductName);
        updateCartTotal();
    }
}
/* Calculate Cart Total */
function updateCartTotal(){
    //init
    var total = 0;
    var price = 0;
    var items = 0;
    var productname = "";
    var carttable = "";
    if(sessionStorage.getItem('cart')) {
        //get cart data & parse to array
        var cart = JSON.parse(sessionStorage.getItem('cart'));
        //get no of items in cart 
        items = cart.length;
        //loop over cart array
        for (var i = 0; i < items; i++){
            //convert each JSON product in array back into object
            var x = JSON.parse(cart[i]);
            //get property value of price
            price = parseFloat(x.price.split('Rs')[1]);
            productname = x.productname;
            //add price to total
            carttable += "<tr><td>" + productname + "</td><td>Rs" + price.toFixed(2) + "</td></tr>";
            total += price;
        }
        
    }
    //update total on website HTML
    document.getElementById("total").innerHTML = total.toFixed(2);
    //insert saved products to cart table
    document.getElementById("carttable").innerHTML = carttable;
    //update items in cart on website HTML
    document.getElementById("itemsquantity").innerHTML = items;
}
//user feedback on successful add
function addedToCart(pname) {
  var message = pname + " was added to the cart";
  var alerts = document.getElementById("alerts");
  alerts.innerHTML = message;
  if(!alerts.classList.contains("message")){
     alerts.classList.add("message");
  }
}
/* User Manually empty cart */
function emptyCart() {
    //remove cart session storage object & refresh cart totals
    if(sessionStorage.getItem('cart')){
        sessionStorage.removeItem('cart');
        updateCartTotal();
      var alerts = document.getElementById("alerts");
      alerts.innerHTML = "";
      if(alerts.classList.contains("message")){
          alerts.classList.remove("message");
      }
    }
}
</script>


    </body>
</html>














if ($rows == 1) {
            echo("header("Location: myorders.php")")";
        } else {
            echo "<div class='form'>
                  <h3>Incorrect Username/password.</h3><br/>
                  <p class='link'>Click here to <a href='login.php'>Login</a> again.</p>
                  </div>";
        }
    } else {
?>

<div id="slides" class="cover-slides">
		<ul class="slides-container">
			<li class="text-left">
				<img src="images/267.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1 class="m-b-20"><strong>Welcome To <br> Maher Kathiyawadi Restaurant</strong></h1>
							<p class="m-b-40">Have It Your Way,   <br> 
							World's Greatest Hamburgers</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Food Menu</a></p>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="images/1-kathiyawadi-restaurants-1-ki1aq.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1 class="m-b-20"><strong>We like  <br> to eat well.</strong></h1>
							<p class="m-b-40">Maher Kathiyawadi Restaurant is serving a Authentic Kathiyawadi Food.And Restaurant's 
<br> 
							Ambience is a very good with well trained staff with open kitchen concept...</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Contact Us</a></p>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="images/DSC_2734.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1 class="m-b-20"><strong>Welcome To <br> Yamifood with Maher</strong></h1>
							<p class="m-b-40">Deliciousness jumping into the mouth<br> 
							We know our food..</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Review</a></p>
						</div>
					</div>
				</div>
			</li>
		</ul>
		<div class="slides-navigation">
			<a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
			<a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
		</div>
	</div>
	<!-- End slides -->
	
	<!-- Start About -->
	<div class="about-section-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 text-center">
					<div class="inner-column">
						<h1>Welcome To <span>Maher Kathiyawadi Restaurant</span></h1>
						<h4>Little Story</h4>
						<p>Restaurants in Ahmedabad, Ahmedabad Restaurants, Bopal restaurants, Best Bopal restaurants, West Ahmedabad restaurants, Gujarati Restaurants in Ahmedabad, Gujarati near me, Gujarati Restaurants in West Ahmedabad, 
Gujarati Restaurants in Bopal, 
 </p>
						<p>Quick Bites in Ahmedabad, Quick Bites near me, Quick Bites in West Ahmedabad, Quick Bites in Bopal, in Ahmedabad, near me, in West Ahmedabad, in Bopal, in Ahmedabad, near me, in West Ahmedabad, in Bopal, New Year Parties in Ahmedabad, Christmas' Special in Ahmedabad,</p>
						<a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Contact Us</a>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12">
					<img src="images/images.jpg"  width="200%" height="200%" class="img-fluid">
				</div>
			</div>
		</div>
	</div>
	<!-- End About -->
	
	<!-- Start QT -->
	<div class="qt-box qt-background">
		<div class="container">
			<div class="row">
				<div class="col-md-8 ml-auto mr-auto text-center">
					<p class="lead ">
						" If you're not the one cooking, stay out of the way and compliment the chef. "
					</p>
					<span class="lead">Maher Restaurent</span>
				</div>
			</div>
		</div>
	</div>




  <div class="container">
<form method="POST">
<span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span><input type="text" id="Form_Search" name="search" style="background-color: #ede5e4;" value="" placeholder="Search for dream pet" role="searchbox" class="InputBox " autocomplete="on"><input type="submit" id="Form_Go" class="Button" name="GO"value="GO">
<?php include "connect.php";
if(isset($_POST['GO']))
{
   $search=$_POST['search'];
   $sql= mysqli_query($con,"select * from pets where pname='$search'");
}?>
</form>
</div>


<div class="row"> 
  <div class="column">
    <img src="ft1 (1).jpeg" style="width:100%">
    <img src="ft1 (2).jpeg" style="width:100%">
    <img src="ft1 (3).jpeg" style="width:100%">
    <img src="ft1 (4).jpeg" style="width:100%">
    <img src="ft1 (5.jpeg" style="width:100%">
    <img src="ft1 (6).jpeg" style="width:100%">
    <img src="ft1 (7).jpeg" style="width:100%">
  </div>
  <div class="column">
    <img src="ft1 (8).jpeg" style="width:100%">
    <img src="ft1 (9).jpeg" style="width:100%">
    <img src="ft1 (10).jpeg" style="width:100%">
    <img src="ft1 (11).jpeg" style="width:100%">
    <img src="ft1 (12).jpeg" style="width:100%">
    <img src="ft1 (13).jpeg" style="width:100%">
  </div>  
</div>


<p><b>COCKATIEL</b></p>
      <p>Cockatiels are funny souls: they’re friendly, intelligent, cheerful, lively, active, curious and love to play.
      </p><br><br>
      <p><b>LOVE BIRDS</b></p>
      <p>Lovebirds are very funny, playful, clumsy and silly little clowns. Their cheeky but very lovable and adorable personalities.</p><br><br><br>
      <p><b>BUGDIE</b></p>
      <p>budgies are very popular because they’re playful, cheerful, peaceful and undemanding. budgies are surprisingly good at learning 
speech and can even mimic whole sentences.</p>



<select id="pets" name="product">
      <option value="Labrador">Labrador</option>
      <option value="shihtzu">shih tzu </option>
      <option value="Golden Retriever">Golden Retriever</option>
      <option value="crossbreed">crossbreed</option>
      <option value="Doberman">Doberman</option>
      <option value="Golden Retriever">Golden Retriever</option>
    </select>

    <input type="text" name="product" placeholder="Your prefered pet.."><br><br>
