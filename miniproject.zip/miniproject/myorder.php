<html>
<head>
    <meta charset="utf-8"/>
    <title>myorders.</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<?php
include('header.php');?>
<body>
<?php
require('db.php');

//Inserting  the values to the table 
if(isset($_POST['submit']))
{
    
    $username=$_REQUEST['username'];
    $email=$_REQUEST['email'];
    $phno=$_REQUEST['phno'];
    $product=$_REQUEST['product'];
    $color=$_REQUEST['color'];
    $price=$_REQUEST['price'];
    $address=$_REQUEST['address'];
    $date=$_REQUEST['date'];
    $sql="INSERT INTO produ_order VALUES('','$username','$email','$phno','$product','$color','$price','$address','$date')";
    $sql=mysqli_query($con,$sql);

}?>
<table id="customer" border="1">
<tr>
<th>ID</th>
<th>USERNAME</th>
<th>EMAIL</th>
<th>PHONE NUMBER</th>
<th>PRODUCT</th>
<th>COLOR</th>
<th>PRICE</th>
<th>ADDRESS</th>
<th>DATE</th>
</tr>
<?php
include('db.php');

$sql="SELECT * FROM produ_order WHERE email= '$email'";
$sql=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($sql))
{
?>
<tr>
<td><?php echo $row['id'];?></td>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['phno'];?></td>
<td><?php echo $row['product'];?></td>
<td><?php echo $row['color'];?></td>
<td><?php echo $row['price'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['date_ordered'];?></td>
</tr>
<?php
}
?>
</table>
</body>
</html>