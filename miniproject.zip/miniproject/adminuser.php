<?php
include('headeradmin.php');
?>
<html>
  <head><title>Dashboard</title></head>
  <body>
    <?php
    include('db.php');?>
    <style>
caption {
    font-size: 1.8rem;
}
table {
    width: 100%;
    font-size: 1.2rem;
    margin: 20px auto;
}
 
tbody tr:nth-child(odd) {
    background: #202932;
}
 
tbody tr:nth-child(even) {
    background: #2c3844;
}
 
tbody {
    color: white;
}
 
table, td, th {
    border-collapse: collapse;
}
 
th, td {
    padding: 10px;
    border: 1px solid #777;
    text-align: center;
}
 
.firstRowFirstColumn {
    width: 400px;}
</style>
<br><br><br>
<table id="customer" border="1">
<tr>
<th>ID</th>
<th>USERNAME</th>
<th>EMAIL</th>
<th>DATE AND TIME</th>
</tr>
<?php

$sql="SELECT * FROM users";
$sql=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($sql))
{
?>
<tr>
<td><?php echo $row['id'];?></td>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['create_datetime'];?></td>
</tr>
<?php
}
?>
</table>
</body>
